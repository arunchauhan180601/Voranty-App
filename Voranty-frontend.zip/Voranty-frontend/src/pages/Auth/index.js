export { Login } from "./Login/Login";
export { Register } from "./Register/";
export { ForgetPassword } from "./ForgetPassword/ForgotPass";
export { OTP } from "./OTP/Otp";
// export { ResetPassword } from "./ResetPassword/";
