export { default as authOne } from "./cover/auth-one.svg";
export { default as authTwo } from "./cover/auth-two.svg";
export { default as resetPassword } from "./cover/reset-password.svg";
